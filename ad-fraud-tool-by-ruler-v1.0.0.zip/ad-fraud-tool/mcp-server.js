#!/usr/bin/env node
/**
 * Ruler Ad Guard — MCP Server
 *
 * Exposes fraud data to Claude Code via the Model Context Protocol (stdio).
 *
 * Add to ~/.claude/settings.json:
 * {
 *   "mcpServers": {
 *     "ruler-ad-guard": {
 *       "command": "node",
 *       "args": ["E:/Claude/ad-fraud-tool/mcp-server.js"]
 *     }
 *   }
 * }
 */
require('dotenv').config({ path: require('path').join(__dirname, '.env') });
const { db, getClientById } = require('./db');
const { scoreClick } = require('./fraud-engine');
const googleAds = require('./integrations/google-ads');
const metaAds   = require('./integrations/meta-ads');

// ── MCP Protocol ──────────────────────────────────────────────────────────────
const TOOLS = [
  {
    name: 'list_clients',
    description: 'List all clients being tracked for ad fraud',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'get_fraud_stats',
    description: 'Get fraud statistics for a client or all clients',
    inputSchema: {
      type: 'object',
      properties: {
        client_id: { type: 'string', description: 'Client ID (omit for all clients)' },
        days:      { type: 'number', description: 'Lookback window in days (default 30)' },
      },
    },
  },
  {
    name: 'get_recent_fraud',
    description: 'Get recent fraudulent or suspicious clicks',
    inputSchema: {
      type: 'object',
      properties: {
        client_id: { type: 'string', description: 'Client ID (omit for all)' },
        verdict:   { type: 'string', enum: ['FRAUD','SUSPICIOUS','CLEAN'], description: 'Filter by verdict' },
        limit:     { type: 'number', description: 'Number of results (default 20)' },
      },
    },
  },
  {
    name: 'get_top_fraud_ips',
    description: 'Get the IPs generating the most suspicious/fraud clicks',
    inputSchema: {
      type: 'object',
      properties: {
        client_id: { type: 'string', description: 'Client ID (omit for all)' },
      },
    },
  },
  {
    name: 'get_blocked_ips',
    description: 'List all IPs currently blocked for a client',
    inputSchema: {
      type: 'object',
      properties: {
        client_id: { type: 'string', description: 'Client ID (omit for all)' },
      },
    },
  },
  {
    name: 'block_ip',
    description: 'Block an IP address and push the exclusion to Google Ads and/or Meta Ads',
    inputSchema: {
      type: 'object',
      required: ['client_id', 'ip'],
      properties: {
        client_id: { type: 'string', description: 'Client ID to block IP for' },
        ip:        { type: 'string', description: 'IP address to block' },
        platforms: { type: 'array', items: { type: 'string' }, description: 'Platforms to push to: ["google","meta"]' },
        reason:    { type: 'string', description: 'Reason for manual block' },
      },
    },
  },
  {
    name: 'unblock_ip',
    description: 'Remove an IP from the block list',
    inputSchema: {
      type: 'object',
      required: ['client_id', 'ip'],
      properties: {
        client_id: { type: 'string' },
        ip:        { type: 'string' },
      },
    },
  },
  {
    name: 'get_flag_breakdown',
    description: 'Get a breakdown of fraud signals detected (which signals are triggering most)',
    inputSchema: {
      type: 'object',
      properties: {
        client_id: { type: 'string', description: 'Client ID (omit for all)' },
      },
    },
  },
  {
    name: 'sync_meta_exclusions',
    description: 'Attach the blocked-IP audience as an exclusion to all active Meta ad sets for a client',
    inputSchema: {
      type: 'object',
      required: ['client_id'],
      properties: {
        client_id: { type: 'string' },
      },
    },
  },
  {
    name: 'get_google_campaign_stats',
    description: 'Pull Google Ads campaign stats including invalid click rate',
    inputSchema: {
      type: 'object',
      required: ['client_id'],
      properties: {
        client_id: { type: 'string' },
        days:      { type: 'number', description: 'Lookback days (default 30)' },
      },
    },
  },
  {
    name: 'get_meta_campaign_stats',
    description: 'Pull Meta Ads campaign stats for a client',
    inputSchema: {
      type: 'object',
      required: ['client_id'],
      properties: {
        client_id: { type: 'string' },
        days:      { type: 'number', description: 'Lookback days (default 30)' },
      },
    },
  },
  {
    name: 'create_client',
    description: 'Register a new client website for fraud tracking',
    inputSchema: {
      type: 'object',
      required: ['name'],
      properties: {
        name:   { type: 'string', description: 'Client name (e.g. "Ena Running")' },
        domain: { type: 'string', description: 'Client website domain (e.g. "ena.gr")' },
      },
    },
  },
  {
    name: 'get_client_snippet',
    description: 'Get the JavaScript tracking snippet to install on a client\'s landing pages',
    inputSchema: {
      type: 'object',
      required: ['client_id'],
      properties: {
        client_id: { type: 'string' },
        server_url: { type: 'string', description: 'The URL of your fraud server (e.g. https://guard.ruler.agency)' },
      },
    },
  },
];

// ── Tool handlers ─────────────────────────────────────────────────────────────
async function callTool(name, args) {
  const FLAG_LABELS = {
    REPEAT_IP:'Repeat IP', DATACENTER_IP:'Datacenter/VPN', BOT_UA:'Bot UA',
    SUSPICIOUS_UA:'Suspicious UA', MISSING_UA:'Missing UA',
    LOW_TIME:'Short session', NO_MOUSE:'No mouse', NO_SCROLL:'No scroll',
    GEO_MISMATCH:'Geo mismatch', NO_CLICK_ID:'Missing click ID',
  };

  switch (name) {
    case 'list_clients': {
      const clients = db.prepare('SELECT id,name,domain,api_key,created_at,google_customer_id,meta_ad_account_id FROM clients WHERE active=1 ORDER BY name').all();
      return clients.map(c => ({
        id: c.id, name: c.name, domain: c.domain,
        api_key: c.api_key,
        google_connected: !!c.google_customer_id,
        meta_connected:   !!c.meta_ad_account_id,
        created: new Date(c.created_at * 1000).toISOString().slice(0,10),
      }));
    }

    case 'get_fraud_stats': {
      const days  = args.days || 30;
      const since = Math.floor(Date.now()/1000) - days * 86400;
      const where = args.client_id ? 'client_id=? AND ts>=?' : 'ts>=?';
      const params = args.client_id ? [args.client_id, since] : [since];

      const stats = db.prepare(`
        SELECT COUNT(*) as total,
          SUM(CASE WHEN score>=75 THEN 1 ELSE 0 END) as fraud,
          SUM(CASE WHEN score>=40 AND score<75 THEN 1 ELSE 0 END) as suspicious,
          SUM(CASE WHEN score<40 THEN 1 ELSE 0 END) as clean,
          SUM(CASE WHEN converted=1 THEN 1 ELSE 0 END) as conversions,
          ROUND(AVG(score),1) as avg_score
        FROM clicks WHERE ${where}
      `).get(...params);

      const blocked = args.client_id
        ? db.prepare('SELECT COUNT(*) as cnt FROM blocked_ips WHERE client_id=?').get(args.client_id).cnt
        : db.prepare('SELECT COUNT(*) as cnt FROM blocked_ips').get().cnt;

      const fraudRate = stats.total ? ((stats.fraud / stats.total)*100).toFixed(1) + '%' : '0%';
      return { ...stats, blocked_ips: blocked, fraud_rate: fraudRate, period_days: days };
    }

    case 'get_recent_fraud': {
      const limit  = args.limit || 20;
      const where  = [];
      const params = [];
      if (args.client_id) { where.push('c.client_id=?'); params.push(args.client_id); }
      if (args.verdict === 'FRAUD')      { where.push('c.score>=75'); }
      if (args.verdict === 'SUSPICIOUS') { where.push('c.score>=40 AND c.score<75'); }
      if (args.verdict === 'CLEAN')      { where.push('c.score<40'); }
      if (!args.verdict)                 { where.push('c.score>=40'); }

      const rows = db.prepare(`
        SELECT c.ip, c.country, c.platform, c.score, c.flags, c.gclid, c.fbclid,
               datetime(c.ts,'unixepoch') as time, cl.name as client,
               s.time_on_page, s.scroll_depth
        FROM clicks c
        LEFT JOIN sessions s ON s.click_id=c.id
        LEFT JOIN clients cl ON cl.id=c.client_id
        ${where.length ? 'WHERE '+where.join(' AND ') : ''}
        ORDER BY c.ts DESC LIMIT ?
      `).all(...params, limit);

      return rows.map(r => ({
        ...r,
        verdict: r.score>=75?'FRAUD':r.score>=40?'SUSPICIOUS':'CLEAN',
        flags: JSON.parse(r.flags||'[]').map(f=>f.code),
      }));
    }

    case 'get_top_fraud_ips': {
      const where  = args.client_id ? 'WHERE score>=40 AND client_id=?' : 'WHERE score>=40';
      const params = args.client_id ? [args.client_id] : [];
      return db.prepare(`
        SELECT ip, country, COUNT(*) as clicks, MAX(score) as max_score, client_id
        FROM clicks ${where}
        GROUP BY ip ORDER BY clicks DESC LIMIT 20
      `).all(...params);
    }

    case 'get_blocked_ips': {
      const where  = args.client_id ? 'WHERE b.client_id=?' : '';
      const params = args.client_id ? [args.client_id] : [];
      const rows   = db.prepare(`
        SELECT b.*, c.name as client_name
        FROM blocked_ips b JOIN clients c ON c.id=b.client_id
        ${where} ORDER BY b.blocked_at DESC
      `).all(...params);
      return rows.map(r => ({
        ...r,
        pushed_to: JSON.parse(r.pushed_to||'[]'),
        blocked_date: new Date(r.blocked_at*1000).toISOString().slice(0,10),
      }));
    }

    case 'block_ip': {
      const { client_id, ip, platforms = ['google','meta'], reason = 'manual' } = args;
      const client = getClientById(client_id);
      if (!client) throw new Error(`Client ${client_id} not found`);

      db.prepare(`INSERT OR IGNORE INTO blocked_ips (client_id,ip,reason,score) VALUES (?,?,?,100)`)
        .run(client_id, ip, reason);

      const pushed = [];
      if (platforms.includes('google') && client.google_client_id) {
        try { await googleAds.blockIpInGoogle(client, ip); pushed.push('google'); }
        catch (e) { pushed.push(`google:error:${e.message}`); }
      }
      if (platforms.includes('meta') && client.meta_access_token) {
        try { await metaAds.blockIpInMeta(client, ip); pushed.push('meta'); }
        catch (e) { pushed.push(`meta:error:${e.message}`); }
      }

      db.prepare('UPDATE blocked_ips SET pushed_to=? WHERE client_id=? AND ip=?')
        .run(JSON.stringify(pushed.filter(p=>!p.includes('error'))), client_id, ip);

      return { blocked: true, ip, client_id, pushed };
    }

    case 'unblock_ip': {
      db.prepare('DELETE FROM blocked_ips WHERE client_id=? AND ip=?').run(args.client_id, args.ip);
      return { unblocked: true, ip: args.ip };
    }

    case 'get_flag_breakdown': {
      const where  = args.client_id ? 'WHERE score>=40 AND client_id=?' : 'WHERE score>=40';
      const rows   = db.prepare(`SELECT flags FROM clicks ${where}`).all(...(args.client_id?[args.client_id]:[]));
      const counts = {};
      for (const r of rows) {
        try { JSON.parse(r.flags||'[]').forEach(f => { counts[f.code]=(counts[f.code]||0)+1; }); } catch {}
      }
      return Object.entries(counts)
        .sort((a,b)=>b[1]-a[1])
        .map(([code,count]) => ({ signal: FLAG_LABELS[code]||code, code, count }));
    }

    case 'sync_meta_exclusions': {
      const client = getClientById(args.client_id);
      if (!client) throw new Error(`Client ${args.client_id} not found`);
      const results = await metaAds.attachExclusionToAdSets(client);
      return { synced_ad_sets: results.length, results };
    }

    case 'get_google_campaign_stats': {
      const client = getClientById(args.client_id);
      if (!client) throw new Error(`Client ${args.client_id} not found`);
      return googleAds.getCampaignStats(client, args.days || 30);
    }

    case 'get_meta_campaign_stats': {
      const client = getClientById(args.client_id);
      if (!client) throw new Error(`Client ${args.client_id} not found`);
      return metaAds.getCampaignStats(client, args.days || 30);
    }

    case 'create_client': {
      const { createClient } = require('./db');
      const client = createClient({ name: args.name, domain: args.domain });
      return {
        id:      client.id,
        name:    client.name,
        domain:  client.domain,
        api_key: client.api_key,
        message: `Client created. Install the tracking snippet using get_client_snippet with this client_id.`,
      };
    }

    case 'get_client_snippet': {
      const server = args.server_url || 'http://localhost:3000';
      const client = getClientById(args.client_id);
      if (!client) throw new Error(`Client ${args.client_id} not found`);
      return {
        snippet: `<!-- Ruler Ad Guard — ${client.name} -->\n<script>\n  var FRAUD_TRACKER_SERVER = "${server}";\n  var FRAUD_TRACKER_KEY    = "${client.api_key}";\n</script>\n<script src="${server}/tracker.js"></script>`,
        api_key: client.api_key,
        note: 'Place in <head> on every landing page connected to Google Ads or Meta Ads campaigns.',
      };
    }

    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

// ── JSON-RPC stdio loop ───────────────────────────────────────────────────────
function send(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

let buffer = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', async chunk => {
  buffer += chunk;
  const lines = buffer.split('\n');
  buffer = lines.pop();

  for (const line of lines) {
    if (!line.trim()) continue;
    let msg;
    try { msg = JSON.parse(line); } catch { continue; }

    if (msg.method === 'initialize') {
      send({
        jsonrpc: '2.0', id: msg.id,
        result: {
          protocolVersion: '2024-11-05',
          capabilities: { tools: {} },
          serverInfo: { name: 'ruler-ad-guard', version: '1.0.0' },
        },
      });

    } else if (msg.method === 'tools/list') {
      send({ jsonrpc: '2.0', id: msg.id, result: { tools: TOOLS } });

    } else if (msg.method === 'tools/call') {
      const { name, arguments: args } = msg.params;
      try {
        const result = await callTool(name, args || {});
        send({
          jsonrpc: '2.0', id: msg.id,
          result: { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] },
        });
      } catch (err) {
        send({
          jsonrpc: '2.0', id: msg.id,
          result: { content: [{ type: 'text', text: `Error: ${err.message}` }], isError: true },
        });
      }

    } else if (msg.method === 'notifications/initialized') {
      // no-op

    } else {
      send({ jsonrpc: '2.0', id: msg.id, error: { code: -32601, message: 'Method not found' } });
    }
  }
});

process.stderr.write('[Ruler Ad Guard MCP] Ready\n');
