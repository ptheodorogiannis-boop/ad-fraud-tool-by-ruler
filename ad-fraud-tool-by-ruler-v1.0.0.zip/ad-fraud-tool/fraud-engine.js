const inRange = require('ip-range-check');

const DATACENTER_CIDRS = [
  '3.0.0.0/8','18.0.0.0/8','34.192.0.0/10','52.0.0.0/8','54.0.0.0/8',
  '34.64.0.0/10','35.184.0.0/13','104.154.0.0/15',
  '13.64.0.0/11','20.0.0.0/8','40.64.0.0/10','52.96.0.0/12',
  '104.131.0.0/18','138.197.0.0/16','159.65.0.0/16','165.227.0.0/16',
  '45.33.0.0/17','45.56.0.0/21','45.79.0.0/16',
  '116.202.0.0/15','136.243.0.0/16','176.9.0.0/18','213.239.192.0/18',
  '51.68.0.0/16','51.75.0.0/16','51.89.0.0/16','54.36.0.0/14',
  '45.32.0.0/14','108.61.0.0/16','149.28.0.0/16',
  '103.21.244.0/22','103.22.200.0/22','104.16.0.0/13',
  '185.220.101.0/24','185.220.102.0/23','199.249.230.0/24',
];

const BOT_UA = [
  /bot|crawl|slurp|spider|fetch|scraper|headless|phantom|selenium|puppeteer|playwright/i,
  /python-requests|curl|wget|java\/|go-http|okhttp|axios/i,
  /facebookexternalhit|twitterbot|linkedinbot|googlebot|bingbot|yandex/i,
  /applebot|duckduckbot|baiduspider|sogou|exabot|ia_archiver/i,
  /postman|insomnia|httpie|grpc|zgrab/i,
];

const SUSPICIOUS_UA = [
  /compatible; MSIE [5-8]\./i,
  /Windows NT 5\.[01]/i,
  /iPhone; CPU iPhone OS [1-6]_/i,
];

function scoreClick(click, recentClicksFromIp, sessionData, client) {
  const threshold     = client?.click_threshold || parseInt(process.env.CLICK_THRESHOLD || '3');
  const targetCountries = (client?.target_countries || process.env.TARGET_COUNTRIES || '')
    .split(',').map(c => c.trim()).filter(Boolean);

  let score = 0;
  const flags = [];

  // 1. Repeat IP
  if (recentClicksFromIp >= threshold) {
    const added = Math.min(30 + (recentClicksFromIp - threshold) * 5, 45);
    score += added;
    flags.push({ code: 'REPEAT_IP', detail: `${recentClicksFromIp} clicks/24h`, weight: added });
  }

  // 2. Datacenter IP
  if (click.ip && isDatacenterIp(click.ip)) {
    score += 35;
    flags.push({ code: 'DATACENTER_IP', detail: 'Known hosting/VPN range', weight: 35 });
  }

  // 3. User-agent
  if (!click.ua) {
    score += 20;
    flags.push({ code: 'MISSING_UA', detail: 'No user-agent', weight: 20 });
  } else if (BOT_UA.some(r => r.test(click.ua))) {
    score += 40;
    flags.push({ code: 'BOT_UA', detail: 'Bot user-agent', weight: 40 });
  } else if (SUSPICIOUS_UA.some(r => r.test(click.ua))) {
    score += 15;
    flags.push({ code: 'SUSPICIOUS_UA', detail: 'Spoofed/outdated UA', weight: 15 });
  }

  // 4. Session quality
  if (sessionData) {
    if (sessionData.time_on_page !== null && sessionData.time_on_page < 3) {
      score += 20;
      flags.push({ code: 'LOW_TIME', detail: `${sessionData.time_on_page}s on page`, weight: 20 });
    }
    if (!sessionData.mouse_moved) {
      score += 10;
      flags.push({ code: 'NO_MOUSE', detail: 'No mouse movement', weight: 10 });
    }
    if (!sessionData.scroll_depth && sessionData.time_on_page > 2) {
      score += 8;
      flags.push({ code: 'NO_SCROLL', detail: 'Zero scroll', weight: 8 });
    }
  }

  // 5. Geo mismatch
  if (targetCountries.length && click.country && !targetCountries.includes(click.country)) {
    score += 20;
    flags.push({ code: 'GEO_MISMATCH', detail: `${click.country} not in target`, weight: 20 });
  }

  // 6. Missing click ID
  if (!click.gclid && !click.fbclid && click.platform !== 'unknown') {
    score += 5;
    flags.push({ code: 'NO_CLICK_ID', detail: 'No gclid/fbclid', weight: 5 });
  }

  score = Math.min(score, 100);
  return { score, flags, verdict: score >= 75 ? 'FRAUD' : score >= 40 ? 'SUSPICIOUS' : 'CLEAN' };
}

function isDatacenterIp(ip) {
  try { return inRange(ip, DATACENTER_CIDRS); } catch { return false; }
}

module.exports = { scoreClick, isDatacenterIp };
