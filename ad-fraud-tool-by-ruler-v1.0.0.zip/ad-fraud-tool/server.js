require('dotenv').config();
const express   = require('express');
const cors      = require('cors');
const rateLimit = require('express-rate-limit');
const geoip     = require('geoip-lite');
const UAParser  = require('ua-parser-js');
const path      = require('path');
const crypto    = require('crypto');

const { db, getClientByKey, getClientById, createClient } = require('./db');
const { scoreClick } = require('./fraud-engine');
const { buildGoogleClient, blockIpInGoogle, getCampaignStats: googleStats } = require('./integrations/google-ads');
const metaAds = require('./integrations/meta-ads');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Rate-limit tracker endpoints
const trackerLimiter = rateLimit({ windowMs: 60_000, max: 120 });
app.use('/api/track', trackerLimiter);

// ── Auth middleware (dashboard) ───────────────────────────────────────────────
function dashAuth(req, res, next) {
  const pwd = process.env.DASHBOARD_PASSWORD || 'changeme';
  const key = req.headers['x-dashboard-key'] || req.query.key;
  if (key !== pwd) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

// ── Resolve client from tracker API key ───────────────────────────────────────
function resolveClient(req, res, next) {
  const key = req.headers['x-api-key'] || req.body?.api_key || req.query.api_key;
  if (!key) return res.status(400).json({ error: 'Missing api_key' });
  const client = getClientByKey(key);
  if (!client) return res.status(403).json({ error: 'Invalid api_key' });
  req.client = client;
  next();
}

// ─────────────────────────────────────────────────────────────────────────────
// TRACKER ENDPOINTS
// ─────────────────────────────────────────────────────────────────────────────
app.post('/api/track/click', resolveClient, async (req, res) => {
  try {
    const client = req.client;
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
    const { ua, referrer, landing_url, gclid, fbclid, session_id, campaign_id, ad_group_id } = req.body;

    const geo     = geoip.lookup(ip) || {};
    const uap     = new UAParser(ua || '');
    const country = geo.country || null;
    const city    = geo.city || null;
    const device  = uap.getDevice().type || 'desktop';
    const browser = uap.getBrowser().name || null;
    const os      = uap.getOS().name || null;

    let platform = 'unknown';
    if (gclid)  platform = 'google';
    if (fbclid) platform = 'meta';

    const recentCount = db.prepare(`
      SELECT COUNT(*) as cnt FROM clicks
      WHERE client_id=? AND ip=? AND ts > unixepoch()-86400
    `).get(client.id, ip).cnt;

    const { score, flags, verdict } = scoreClick(
      { ip, ua, country, gclid, fbclid, platform },
      recentCount,
      null,
      client
    );

    const result = db.prepare(`
      INSERT INTO clicks
        (client_id,ip,country,city,ua,device_type,browser,os,referrer,landing_url,
         campaign_id,ad_group_id,gclid,fbclid,platform,score,flags,blocked)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(
      client.id, ip, country, city, ua, device, browser, os,
      referrer||null, landing_url||null,
      campaign_id||null, ad_group_id||null,
      gclid||null, fbclid||null,
      platform, score, JSON.stringify(flags), verdict==='FRAUD'?1:0
    );

    const clickId = result.lastInsertRowid;
    if (score >= (client.auto_block_score || 75)) {
      autoBlock(client, ip, score, flags, platform).catch(() => {});
    }

    res.json({ ok: true, click_id: clickId, score, verdict });
  } catch (err) {
    console.error('[track/click]', err.message);
    res.status(500).json({ error: 'Internal error' });
  }
});

app.post('/api/track/session', resolveClient, async (req, res) => {
  try {
    const client = req.client;
    const { click_id, session_id, time_on_page, scroll_depth, mouse_moved, clicks_count } = req.body;

    db.prepare(`
      INSERT INTO sessions (click_id,session_id,time_on_page,scroll_depth,mouse_moved,clicks_count,ts_end)
      VALUES (?,?,?,?,?,?,unixepoch())
      ON CONFLICT(session_id) DO UPDATE SET
        time_on_page=excluded.time_on_page, scroll_depth=excluded.scroll_depth,
        mouse_moved=excluded.mouse_moved, clicks_count=excluded.clicks_count, ts_end=unixepoch()
    `).run(click_id, session_id, time_on_page, scroll_depth, mouse_moved?1:0, clicks_count||0);

    if (click_id) {
      const click = db.prepare('SELECT * FROM clicks WHERE id=? AND client_id=?').get(click_id, client.id);
      if (click) {
        const recentCount = db.prepare(`
          SELECT COUNT(*) as cnt FROM clicks WHERE client_id=? AND ip=? AND ts>unixepoch()-86400
        `).get(client.id, click.ip).cnt;

        const { score, flags, verdict } = scoreClick(
          click, recentCount,
          { time_on_page, scroll_depth, mouse_moved, clicks_count },
          client
        );
        db.prepare('UPDATE clicks SET score=?,flags=?,blocked=? WHERE id=?')
          .run(score, JSON.stringify(flags), verdict==='FRAUD'?1:0, click_id);

        if (score >= (client.auto_block_score || 75)) {
          autoBlock(client, click.ip, score, flags, click.platform).catch(() => {});
        }
      }
    }
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: 'Internal error' }); }
});

app.post('/api/track/conversion', resolveClient, (req, res) => {
  const { gclid, fbclid, value } = req.body;
  const cid = req.client.id;
  if (gclid) {
    db.prepare('UPDATE clicks SET converted=1 WHERE client_id=? AND gclid=?').run(cid, gclid);
    const c = db.prepare('SELECT id FROM clicks WHERE client_id=? AND gclid=? LIMIT 1').get(cid, gclid);
    if (c) db.prepare('INSERT INTO conversions (click_id,gclid,value) VALUES (?,?,?)').run(c.id, gclid, value||0);
  }
  if (fbclid) {
    db.prepare('UPDATE clicks SET converted=1 WHERE client_id=? AND fbclid=?').run(cid, fbclid);
    const c = db.prepare('SELECT id FROM clicks WHERE client_id=? AND fbclid=? LIMIT 1').get(cid, fbclid);
    if (c) db.prepare('INSERT INTO conversions (click_id,fbclid,value) VALUES (?,?,?)').run(c.id, fbclid, value||0);
  }
  res.json({ ok: true });
});

// ─────────────────────────────────────────────────────────────────────────────
// DASHBOARD API
// ─────────────────────────────────────────────────────────────────────────────
app.use('/api/dashboard', dashAuth);

// Client management
app.get('/api/dashboard/clients', (req, res) => {
  const clients = db.prepare('SELECT * FROM clients WHERE active=1 ORDER BY created_at DESC').all();
  res.json(clients.map(sanitizeClient));
});

app.post('/api/dashboard/clients', (req, res) => {
  const { name, domain } = req.body;
  if (!name) return res.status(400).json({ error: 'name required' });
  const client = createClient({ name, domain });
  res.json(sanitizeClient(client));
});

app.put('/api/dashboard/clients/:id', (req, res) => {
  const c = req.body;
  db.prepare(`
    UPDATE clients SET
      name=COALESCE(?,name), domain=COALESCE(?,domain),
      google_customer_id=COALESCE(?,google_customer_id),
      google_client_id=COALESCE(?,google_client_id),
      google_client_secret=COALESCE(?,google_client_secret),
      google_dev_token=COALESCE(?,google_dev_token),
      google_refresh_token=COALESCE(?,google_refresh_token),
      meta_access_token=COALESCE(?,meta_access_token),
      meta_ad_account_id=COALESCE(?,meta_ad_account_id),
      click_threshold=COALESCE(?,click_threshold),
      auto_block_score=COALESCE(?,auto_block_score),
      target_countries=COALESCE(?,target_countries)
    WHERE id=?
  `).run(
    c.name||null, c.domain||null,
    c.google_customer_id||null, c.google_client_id||null,
    c.google_client_secret||null, c.google_dev_token||null,
    c.google_refresh_token||null, c.meta_access_token||null,
    c.meta_ad_account_id||null, c.click_threshold||null,
    c.auto_block_score||null, c.target_countries||null,
    req.params.id
  );
  res.json({ ok: true });
});

app.delete('/api/dashboard/clients/:id', (req, res) => {
  db.prepare('UPDATE clients SET active=0 WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// Stats
app.get('/api/dashboard/stats', (req, res) => {
  const days = parseInt(req.query.days || '30');
  const cid  = req.query.client_id;
  const since = Math.floor(Date.now()/1000) - days * 86400;

  const where = cid ? 'client_id=? AND ts>=?' : 'ts>=?';
  const params = cid ? [cid, since] : [since];

  const totals = db.prepare(`
    SELECT COUNT(*) as total_clicks,
      SUM(CASE WHEN score>=75 THEN 1 ELSE 0 END) as fraud_clicks,
      SUM(CASE WHEN score>=40 AND score<75 THEN 1 ELSE 0 END) as suspicious_clicks,
      SUM(CASE WHEN converted=1 THEN 1 ELSE 0 END) as conversions,
      AVG(score) as avg_score
    FROM clicks WHERE ${where}
  `).get(...params);

  const blockedQ = cid
    ? db.prepare('SELECT COUNT(*) as cnt FROM blocked_ips WHERE client_id=?').get(cid)
    : db.prepare('SELECT COUNT(*) as cnt FROM blocked_ips').get();

  // Estimate wasted spend (fraud clicks * avg CPC if available, else 0)
  res.json({ ...totals, blocked_ips: blockedQ.cnt, days });
});

app.get('/api/dashboard/clicks', (req, res) => {
  const days   = parseInt(req.query.days || '7');
  const limit  = parseInt(req.query.limit || '100');
  const offset = parseInt(req.query.offset || '0');
  const filter = req.query.filter;
  const cid    = req.query.client_id;
  const since  = Math.floor(Date.now()/1000) - days * 86400;

  let where = 'WHERE c.ts>=?';
  const params = [since];
  if (cid) { where += ' AND c.client_id=?'; params.push(cid); }
  if (filter==='fraud')      where += ' AND c.score>=75';
  if (filter==='suspicious') where += ' AND c.score>=40 AND c.score<75';
  if (filter==='clean')      where += ' AND c.score<40';

  const clicks = db.prepare(`
    SELECT c.*, s.time_on_page, s.scroll_depth, s.mouse_moved,
           cl.name as client_name
    FROM clicks c
    LEFT JOIN sessions s ON s.click_id=c.id
    LEFT JOIN clients cl ON cl.id=c.client_id
    ${where} ORDER BY c.ts DESC LIMIT ? OFFSET ?
  `).all(...params, limit, offset);

  const total = db.prepare(`SELECT COUNT(*) as cnt FROM clicks c ${where}`).get(...params).cnt;
  res.json({ clicks, total, limit, offset });
});

app.get('/api/dashboard/chart', (req, res) => {
  const days = parseInt(req.query.days || '14');
  const cid  = req.query.client_id;
  const where = cid ? 'AND client_id=?' : '';
  const params = cid ? [days, cid] : [days];

  const rows = db.prepare(`
    SELECT date(ts,'unixepoch') as day,
      COUNT(*) as total,
      SUM(CASE WHEN score>=75 THEN 1 ELSE 0 END) as fraud,
      SUM(CASE WHEN score>=40 AND score<75 THEN 1 ELSE 0 END) as suspicious
    FROM clicks
    WHERE ts>=unixepoch()-?*86400 ${where}
    GROUP BY day ORDER BY day ASC
  `).all(...params);
  res.json(rows);
});

app.get('/api/dashboard/top-fraud-ips', (req, res) => {
  const cid   = req.query.client_id;
  const where = cid ? 'WHERE score>=40 AND client_id=?' : 'WHERE score>=40';
  const params = cid ? [cid] : [];
  const rows = db.prepare(`
    SELECT ip, country, COUNT(*) as click_count, MAX(score) as max_score, client_id
    FROM clicks ${where}
    GROUP BY ip ORDER BY click_count DESC LIMIT 20
  `).all(...params);
  res.json(rows);
});

app.get('/api/dashboard/flag-breakdown', (req, res) => {
  const cid   = req.query.client_id;
  const where = cid ? 'WHERE score>=40 AND client_id=?' : 'WHERE score>=40';
  const rows  = db.prepare(`SELECT flags FROM clicks ${where}`).all(...(cid?[cid]:[]));
  const counts = {};
  for (const r of rows) {
    try { JSON.parse(r.flags||'[]').forEach(f => { counts[f.code]=(counts[f.code]||0)+1; }); } catch {}
  }
  res.json(counts);
});

app.get('/api/dashboard/blocked-ips', (req, res) => {
  const cid   = req.query.client_id;
  const where = cid ? 'WHERE client_id=?' : '';
  const ips   = db.prepare(`SELECT * FROM blocked_ips ${where} ORDER BY blocked_at DESC`).all(...(cid?[cid]:[]));
  res.json(ips);
});

app.post('/api/dashboard/block', async (req, res) => {
  const { ip, client_id, platforms = ['google','meta'] } = req.body;
  if (!ip || !client_id) return res.status(400).json({ error: 'ip and client_id required' });
  const client = getClientById(client_id);
  if (!client) return res.status(404).json({ error: 'Client not found' });

  db.prepare(`INSERT OR IGNORE INTO blocked_ips (client_id,ip,reason,score) VALUES (?,?,'manual',100)`).run(client_id, ip);
  const pushed = await pushToAdPlatforms(client, ip, platforms);
  db.prepare('UPDATE blocked_ips SET pushed_to=? WHERE client_id=? AND ip=?').run(JSON.stringify(pushed), client_id, ip);
  res.json({ ok: true, pushed });
});

app.delete('/api/dashboard/block/:client_id/:ip', (req, res) => {
  db.prepare('DELETE FROM blocked_ips WHERE client_id=? AND ip=?').run(req.params.client_id, req.params.ip);
  res.json({ ok: true });
});

app.post('/api/dashboard/meta/attach-exclusion', async (req, res) => {
  const { client_id } = req.body;
  const client = getClientById(client_id);
  if (!client) return res.status(404).json({ error: 'Client not found' });
  try {
    const results = await metaAds.attachExclusionToAdSets(client);
    res.json({ ok: true, results });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────
async function autoBlock(client, ip, score, flags, platform) {
  const existing = db.prepare('SELECT ip FROM blocked_ips WHERE client_id=? AND ip=?').get(client.id, ip);
  if (existing) return;

  db.prepare(`INSERT OR IGNORE INTO blocked_ips (client_id,ip,reason,score) VALUES (?,?,?,?)`)
    .run(client.id, ip, JSON.stringify(flags.map(f=>f.code)), score);

  const platforms = [];
  if (platform === 'google' || platform === 'unknown') platforms.push('google');
  if (platform === 'meta'   || platform === 'unknown') platforms.push('meta');

  const pushed = await pushToAdPlatforms(client, ip, platforms);
  if (pushed.length) {
    db.prepare('UPDATE blocked_ips SET pushed_to=?,auto_pushed=1 WHERE client_id=? AND ip=?')
      .run(JSON.stringify(pushed), client.id, ip);
  }
  console.log(`[auto-block] ${client.name} → ${ip} score=${score} pushed=${pushed.join(',')}`);
}

const _googleListCache = {};
async function pushToAdPlatforms(client, ip, platforms) {
  const pushed = [];
  if (platforms.includes('google') && client.google_client_id) {
    try {
      if (!_googleListCache[client.id]) {
        _googleListCache[client.id] = await blockIpInGoogle(client, ip);
      } else {
        await blockIpInGoogle(client, ip, _googleListCache[client.id]);
      }
      pushed.push('google');
    } catch (e) { console.error(`[google] ${client.name}:`, e.message); }
  }
  if (platforms.includes('meta') && client.meta_access_token) {
    try {
      await metaAds.blockIpInMeta(client, ip);
      pushed.push('meta');
    } catch (e) { console.error(`[meta] ${client.name}:`, e.message); }
  }
  return pushed;
}

function sanitizeClient(c) {
  const { google_client_secret, google_refresh_token, meta_access_token, ...safe } = c;
  return {
    ...safe,
    has_google: !!(c.google_client_id && c.google_refresh_token),
    has_meta:   !!(c.meta_access_token),
  };
}

app.listen(PORT, () => {
  console.log(`\n🛡  Ruler Ad Guard — http://localhost:${PORT}`);
  console.log(`   Dashboard: http://localhost:${PORT}?key=${process.env.DASHBOARD_PASSWORD||'changeme'}\n`);
  console.log(`   MCP Server: node mcp-server.js\n`);
});
