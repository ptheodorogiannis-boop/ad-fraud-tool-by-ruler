"""
Ruler Ad Guard — Developer Implementation Brief
Generates a professional PDF to send to the developer.
"""

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, KeepTogether, PageBreak
)
from reportlab.platypus.flowables import Flowable
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import os

# ── Colours ───────────────────────────────────────────────────────────────────
RULER_RED   = colors.HexColor('#E8193C')
DARK_BG     = colors.HexColor('#07090F')
SURFACE     = colors.HexColor('#0D1018')
CARD        = colors.HexColor('#111520')
BORDER      = colors.HexColor('#1C2236')
TEXT        = colors.HexColor('#E4EAF8')
TEXT_2      = colors.HexColor('#8898BC')
TEXT_3      = colors.HexColor('#4D5F88')
CODE_BG     = colors.HexColor('#0D1018')
CODE_TEXT   = colors.HexColor('#C9D8F0')
GREEN       = colors.HexColor('#10B981')
AMBER       = colors.HexColor('#F59E0B')
WHITE       = colors.white
BLACK       = colors.HexColor('#07090F')

W, H = A4  # 210 x 297 mm

# ── Page template with header/footer ─────────────────────────────────────────
def on_page(canvas, doc):
    canvas.saveState()

    # Top bar
    canvas.setFillColor(DARK_BG)
    canvas.rect(0, H - 14*mm, W, 14*mm, fill=1, stroke=0)

    # Red accent line
    canvas.setFillColor(RULER_RED)
    canvas.rect(0, H - 14*mm, W, 1.2*mm, fill=1, stroke=0)

    # Header text
    canvas.setFillColor(WHITE)
    canvas.setFont('Helvetica-Bold', 8)
    canvas.drawString(15*mm, H - 9*mm, 'RULER AD GUARD')
    canvas.setFont('Helvetica', 7)
    canvas.setFillColor(TEXT_3)
    canvas.drawRightString(W - 15*mm, H - 9*mm, 'Developer Implementation Brief — Confidential')

    # Footer
    canvas.setFillColor(SURFACE)
    canvas.rect(0, 0, W, 10*mm, fill=1, stroke=0)
    canvas.setFillColor(RULER_RED)
    canvas.rect(0, 10*mm, W, 0.5*mm, fill=1, stroke=0)
    canvas.setFont('Helvetica', 7)
    canvas.setFillColor(TEXT_3)
    canvas.drawString(15*mm, 3.5*mm, 'ruler.agency  ·  Made by Ruler Agency')
    canvas.drawRightString(W - 15*mm, 3.5*mm, f'Page {doc.page}')

    canvas.restoreState()


# ── Styles ────────────────────────────────────────────────────────────────────
def make_styles():
    s = {}

    s['cover_title'] = ParagraphStyle('cover_title',
        fontName='Helvetica-Bold', fontSize=30, leading=36,
        textColor=WHITE, spaceAfter=4*mm)

    s['cover_sub'] = ParagraphStyle('cover_sub',
        fontName='Helvetica', fontSize=13, leading=18,
        textColor=TEXT_2, spaceAfter=2*mm)

    s['cover_label'] = ParagraphStyle('cover_label',
        fontName='Helvetica-Bold', fontSize=8, leading=12,
        textColor=RULER_RED, spaceBefore=2*mm, spaceAfter=1*mm,
        letterSpacing=1.5)

    s['h1'] = ParagraphStyle('h1',
        fontName='Helvetica-Bold', fontSize=15, leading=20,
        textColor=WHITE, spaceBefore=7*mm, spaceAfter=3*mm)

    s['h2'] = ParagraphStyle('h2',
        fontName='Helvetica-Bold', fontSize=11, leading=15,
        textColor=TEXT, spaceBefore=5*mm, spaceAfter=2*mm)

    s['h3'] = ParagraphStyle('h3',
        fontName='Helvetica-Bold', fontSize=9, leading=13,
        textColor=TEXT_2, spaceBefore=3*mm, spaceAfter=1.5*mm,
        letterSpacing=0.5)

    s['body'] = ParagraphStyle('body',
        fontName='Helvetica', fontSize=9, leading=14,
        textColor=TEXT_2, spaceAfter=2*mm)

    s['note'] = ParagraphStyle('note',
        fontName='Helvetica', fontSize=8, leading=12,
        textColor=TEXT_3, spaceAfter=2*mm, leftIndent=4*mm)

    s['code'] = ParagraphStyle('code',
        fontName='Courier', fontSize=7.5, leading=11,
        textColor=CODE_TEXT, spaceAfter=0)

    s['code_label'] = ParagraphStyle('code_label',
        fontName='Helvetica-Bold', fontSize=7, leading=10,
        textColor=TEXT_3, spaceBefore=3*mm, spaceAfter=1*mm,
        letterSpacing=1)

    s['tag'] = ParagraphStyle('tag',
        fontName='Helvetica-Bold', fontSize=7, leading=10,
        textColor=RULER_RED, spaceAfter=1*mm, letterSpacing=1.5)

    s['center'] = ParagraphStyle('center',
        fontName='Helvetica', fontSize=8, leading=12,
        textColor=TEXT_3, alignment=TA_CENTER)

    return s


# ── Helpers ───────────────────────────────────────────────────────────────────
class RedBar(Flowable):
    """Thin horizontal rule in ruler red."""
    def __init__(self, height=0.8, spaceBefore=2, spaceAfter=4):
        Flowable.__init__(self)
        self._h = height * mm
        self._sb = spaceBefore * mm
        self._sa = spaceAfter * mm

    def wrap(self, *args):
        return (W - 30*mm, self._h + self._sb + self._sa)

    def draw(self):
        self.canv.setFillColor(RULER_RED)
        self.canv.rect(0, self._sa, W - 30*mm, self._h, fill=1, stroke=0)


def code_block(lines, s, label=None):
    """Return a styled code block as a list of flowables."""
    out = []
    if label:
        out.append(Paragraph(label.upper(), s['code_label']))

    # Build inner paragraphs
    inner = [Paragraph(line.replace(' ', '&nbsp;').replace('<', '&lt;').replace('>', '&gt;') or '&nbsp;', s['code'])
             for line in lines]

    # Wrap in a Table for background colour
    tbl = Table([[inner]], colWidths=[W - 30*mm])
    tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), CODE_BG),
        ('LEFTPADDING',  (0,0), (-1,-1), 10),
        ('RIGHTPADDING', (0,0), (-1,-1), 10),
        ('TOPPADDING',   (0,0), (-1,-1), 8),
        ('BOTTOMPADDING',(0,0), (-1,-1), 8),
        ('LINEAFTER',  (0,0), (0,-1), 3, RULER_RED),
        ('ROUNDEDCORNERS', [3]),
    ]))
    out.append(tbl)
    out.append(Spacer(1, 3*mm))
    return out


def info_table(rows, s):
    """Key/value table."""
    data = [[Paragraph(f'<b>{k}</b>', s['body']),
             Paragraph(v, s['body'])] for k, v in rows]
    tbl = Table(data, colWidths=[55*mm, W - 30*mm - 55*mm])
    tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), CARD),
        ('BACKGROUND', (0,0), (0,-1), SURFACE),
        ('TEXTCOLOR',  (0,0), (0,-1), TEXT_3),
        ('LEFTPADDING',  (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
        ('TOPPADDING',   (0,0), (-1,-1), 6),
        ('BOTTOMPADDING',(0,0), (-1,-1), 6),
        ('GRID', (0,0), (-1,-1), 0.3, BORDER),
        ('ROUNDEDCORNERS', [3]),
    ]))
    return [tbl, Spacer(1, 3*mm)]


def alert(text, s, color=RULER_RED):
    """Highlighted alert/tip box."""
    p = Paragraph(text, s['body'])
    tbl = Table([[p]], colWidths=[W - 30*mm])
    tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#1A0810')),
        ('LEFTPADDING',  (0,0), (-1,-1), 10),
        ('RIGHTPADDING', (0,0), (-1,-1), 10),
        ('TOPPADDING',   (0,0), (-1,-1), 7),
        ('BOTTOMPADDING',(0,0), (-1,-1), 7),
        ('LINEAFTER', (0,0), (0,-1), 3, color),
        ('LINEBEFORE',(0,0), (0,-1), 3, color),
    ]))
    return [tbl, Spacer(1, 3*mm)]


def section_tag(text, s):
    return [Paragraph(text.upper(), s['tag'])]


# ── Build document ────────────────────────────────────────────────────────────
def build():
    out_path = os.path.join(os.path.dirname(__file__), 'RulerAdGuard_DevBrief.pdf')
    doc = SimpleDocTemplate(
        out_path,
        pagesize=A4,
        leftMargin=15*mm, rightMargin=15*mm,
        topMargin=20*mm, bottomMargin=16*mm,
        onPage=on_page,
    )
    s = make_styles()
    story = []

    # ── COVER ─────────────────────────────────────────────────────────────────
    # Dark cover background using a table
    cover_content = [
        Spacer(1, 18*mm),
        Paragraph('RULER', ParagraphStyle('rl', fontName='Helvetica-Bold', fontSize=9,
            textColor=RULER_RED, letterSpacing=4, spaceAfter=1*mm)),
        Paragraph('Ad Guard', ParagraphStyle('ag', fontName='Helvetica-Bold', fontSize=38,
            textColor=WHITE, leading=42, spaceAfter=3*mm)),
        Paragraph('Developer Implementation Brief', ParagraphStyle('dib',
            fontName='Helvetica', fontSize=14, textColor=TEXT_2, spaceAfter=10*mm)),
        HRFlowable(width='100%', thickness=1, color=RULER_RED, spaceAfter=8*mm),
        Paragraph('Self-hosted ad fraud detection and IP blocking for Google Ads and Meta Ads. '
                  'Multi-tenant — tracks multiple client websites from a single installation.',
                  ParagraphStyle('cd', fontName='Helvetica', fontSize=10, textColor=TEXT_2,
                  leading=16, spaceAfter=10*mm)),
    ]

    # Meta info grid
    meta = Table([
        [Paragraph('STACK', ParagraphStyle('ml', fontName='Helvetica-Bold', fontSize=7,
                    textColor=TEXT_3, letterSpacing=1.5)),
         Paragraph('Node.js 18+, Express, SQLite (better-sqlite3)',
                    ParagraphStyle('mv', fontName='Helvetica', fontSize=9, textColor=TEXT))],
        [Paragraph('INTEGRATIONS', ParagraphStyle('ml', fontName='Helvetica-Bold', fontSize=7,
                    textColor=TEXT_3, letterSpacing=1.5)),
         Paragraph('Google Ads API v17, Meta Graph API v20',
                    ParagraphStyle('mv', fontName='Helvetica', fontSize=9, textColor=TEXT))],
        [Paragraph('PROTOCOL', ParagraphStyle('ml', fontName='Helvetica-Bold', fontSize=7,
                    textColor=TEXT_3, letterSpacing=1.5)),
         Paragraph('REST + MCP (Model Context Protocol for Claude Code)',
                    ParagraphStyle('mv', fontName='Helvetica', fontSize=9, textColor=TEXT))],
        [Paragraph('PREPARED BY', ParagraphStyle('ml', fontName='Helvetica-Bold', fontSize=7,
                    textColor=TEXT_3, letterSpacing=1.5)),
         Paragraph('Ruler Agency  ·  ruler.agency',
                    ParagraphStyle('mv', fontName='Helvetica', fontSize=9, textColor=RULER_RED))],
    ], colWidths=[45*mm, W - 30*mm - 45*mm])
    meta.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), SURFACE),
        ('GRID', (0,0), (-1,-1), 0.4, BORDER),
        ('TOPPADDING',   (0,0), (-1,-1), 7),
        ('BOTTOMPADDING',(0,0), (-1,-1), 7),
        ('LEFTPADDING',  (0,0), (-1,-1), 10),
        ('RIGHTPADDING', (0,0), (-1,-1), 10),
    ]))
    cover_content.append(meta)
    cover_content.append(Spacer(1, 12*mm))
    cover_content.append(Paragraph(
        'This document is for internal use. All credentials must be stored securely and never committed to version control.',
        ParagraphStyle('warn', fontName='Helvetica', fontSize=8, textColor=TEXT_3,
        alignment=TA_CENTER)))

    cover_tbl = Table([[cover_content]], colWidths=[W - 30*mm])
    cover_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), DARK_BG),
        ('LEFTPADDING',  (0,0), (-1,-1), 14),
        ('RIGHTPADDING', (0,0), (-1,-1), 14),
        ('TOPPADDING',   (0,0), (-1,-1), 0),
        ('BOTTOMPADDING',(0,0), (-1,-1), 14),
    ]))
    story.append(cover_tbl)
    story.append(PageBreak())

    # ── 1. OVERVIEW ───────────────────────────────────────────────────────────
    story += section_tag('01 — Overview', s)
    story.append(Paragraph('What Is Ruler Ad Guard?', s['h1']))
    story.append(Paragraph(
        'Ruler Ad Guard is a self-hosted ad fraud detection system built for Ruler Agency. '
        'It monitors clicks arriving at client landing pages via Google Ads and Meta Ads, '
        'scores each click for fraud signals, and automatically pushes fraudulent IP addresses '
        'to Google Ads IP exclusion lists and Meta Ads custom audience exclusions.',
        s['body']))
    story.append(Spacer(1, 2*mm))

    story.append(Paragraph('System Components', s['h2']))
    comp_data = [
        ['Component', 'File', 'Purpose'],
        ['HTTP Server', 'server.js', 'Express API — receives click events, manages clients, exposes dashboard API'],
        ['Fraud Engine', 'fraud-engine.js', 'Scores each click 0–100 using 10 fraud signals'],
        ['Database', 'db.js + data/fraud.db', 'SQLite — stores clicks, sessions, blocked IPs, clients'],
        ['Google Ads', 'integrations/google-ads.js', 'Creates IP exclusion lists, blocks IPs per client credentials'],
        ['Meta Ads', 'integrations/meta-ads.js', 'Creates suppression audiences, attaches exclusions to ad sets'],
        ['Tracker', 'public/tracker.js', 'Client-side JS snippet — installed on landing pages'],
        ['Dashboard', 'public/index.html', 'Browser UI — multi-client overview, click log, blocked IPs'],
        ['MCP Server', 'mcp-server.js', 'Exposes 13 tools to Claude Code via Model Context Protocol'],
    ]
    comp_tbl = Table(comp_data, colWidths=[32*mm, 48*mm, W - 30*mm - 32*mm - 48*mm])
    comp_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), SURFACE),
        ('BACKGROUND', (0,1), (-1,-1), CARD),
        ('BACKGROUND', (0,1), (0,-1), SURFACE),
        ('TEXTCOLOR',  (0,0), (-1,0), TEXT_3),
        ('TEXTCOLOR',  (0,1), (0,-1), TEXT_3),
        ('FONTNAME',   (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE',   (0,0), (-1,-1), 8),
        ('GRID', (0,0), (-1,-1), 0.3, BORDER),
        ('TOPPADDING',   (0,0), (-1,-1), 6),
        ('BOTTOMPADDING',(0,0), (-1,-1), 6),
        ('LEFTPADDING',  (0,0), (-1,-1), 8),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [CARD, colors.HexColor('#131825')]),
    ]))
    story.append(comp_tbl)
    story.append(Spacer(1, 3*mm))

    story.append(Paragraph('Fraud Scoring System', s['h2']))
    story.append(Paragraph(
        'Every click is scored from 0 to 100. A score of 75 or above triggers automatic '
        'IP blocking and pushes the exclusion to the ad platforms. The threshold is configurable per client.',
        s['body']))
    score_data = [
        ['Signal', 'Points', 'Description'],
        ['Repeat IP clicks', '30–45', 'Same IP clicked more than 3 times in 24 hours'],
        ['Datacenter / VPN IP', '35', 'IP belongs to AWS, GCP, Azure, DigitalOcean, Tor, etc.'],
        ['Bot user-agent', '40', 'UA matches known crawler / headless browser patterns'],
        ['Suspicious user-agent', '15', 'Very old or spoofed browser (IE6, XP, ancient iOS)'],
        ['Missing user-agent', '20', 'No UA header at all'],
        ['Short session (<3 sec)', '20', 'Visitor left before 3 seconds'],
        ['No mouse movement', '10', 'No mousemove event detected'],
        ['No scroll', '8', 'Zero scroll depth with time on page > 2s'],
        ['Geo mismatch', '20', 'IP country not in the client\'s target country list'],
        ['Missing click ID', '5', 'No gclid or fbclid despite being an ad click'],
    ]
    score_tbl = Table(score_data, colWidths=[52*mm, 18*mm, W - 30*mm - 52*mm - 18*mm])
    score_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), SURFACE),
        ('BACKGROUND', (0,1), (-1,-1), CARD),
        ('TEXTCOLOR',  (0,0), (-1,0), TEXT_3),
        ('TEXTCOLOR',  (1,1), (1,-1), RULER_RED),
        ('FONTNAME',   (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTNAME',   (1,1), (1,-1), 'Courier-Bold'),
        ('FONTSIZE',   (0,0), (-1,-1), 8),
        ('GRID', (0,0), (-1,-1), 0.3, BORDER),
        ('TOPPADDING',   (0,0), (-1,-1), 5),
        ('BOTTOMPADDING',(0,0), (-1,-1), 5),
        ('LEFTPADDING',  (0,0), (-1,-1), 8),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [CARD, colors.HexColor('#131825')]),
    ]))
    story.append(score_tbl)
    story.append(PageBreak())

    # ── 2. SERVER SETUP ───────────────────────────────────────────────────────
    story += section_tag('02 — Server Setup', s)
    story.append(Paragraph('Requirements & Installation', s['h1']))

    story.append(Paragraph('System Requirements', s['h2']))
    story += info_table([
        ('Node.js',   '18 or higher  (check: node --version)'),
        ('npm',       '9 or higher'),
        ('OS',        'Linux (Ubuntu 22.04+ recommended) or Windows Server'),
        ('RAM',       '512 MB minimum, 1 GB recommended'),
        ('Storage',   '2 GB minimum for database growth'),
        ('Open ports','3000 (or custom) — expose via nginx reverse proxy'),
    ], s)

    story.append(Paragraph('Installation Steps', s['h2']))
    story += code_block([
        '# 1. Upload the project to your server',
        'scp -r ad-fraud-tool/ user@yourserver:/var/www/ruler-ad-guard',
        '',
        '# 2. SSH into server and install dependencies',
        'cd /var/www/ruler-ad-guard',
        'npm install --production',
        '',
        '# 3. Copy and configure environment file',
        'cp .env.example .env',
        'nano .env   # Fill in all credentials (see Section 03)',
        '',
        '# 4. Create data directory (SQLite database lives here)',
        'mkdir -p data',
        '',
        '# 5. Start the server (test first)',
        'npm start',
        '# Should print: Ruler Ad Guard running at http://localhost:3000',
    ], s, label='Terminal')

    story.append(Paragraph('Running as a System Service (PM2)', s['h2']))
    story.append(Paragraph(
        'Use PM2 to keep the server running after reboots and crashes:', s['body']))
    story += code_block([
        '# Install PM2 globally',
        'npm install -g pm2',
        '',
        '# Start the app',
        'pm2 start server.js --name ruler-ad-guard',
        '',
        '# Save PM2 process list and enable auto-start on reboot',
        'pm2 save',
        'pm2 startup   # Follow the command it prints',
        '',
        '# Useful commands',
        'pm2 status             # Check if running',
        'pm2 logs ruler-ad-guard  # View logs',
        'pm2 restart ruler-ad-guard',
    ], s, label='PM2 Process Manager')

    story.append(Paragraph('Nginx Reverse Proxy (HTTPS)', s['h2']))
    story.append(Paragraph(
        'Place the server behind Nginx with SSL. Example config for a subdomain:', s['body']))
    story += code_block([
        'server {',
        '    listen 443 ssl;',
        '    server_name guard.ruler.agency;',
        '',
        '    ssl_certificate     /etc/letsencrypt/live/guard.ruler.agency/fullchain.pem;',
        '    ssl_certificate_key /etc/letsencrypt/live/guard.ruler.agency/privkey.pem;',
        '',
        '    location / {',
        '        proxy_pass http://localhost:3000;',
        '        proxy_set_header Host $host;',
        '        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;',
        '        proxy_set_header X-Real-IP $remote_addr;',
        '    }',
        '}',
    ], s, label='nginx config — /etc/nginx/sites-available/ruler-ad-guard')
    story += alert(
        '<b>Important:</b> The X-Forwarded-For header is critical — the fraud engine uses it to '
        'get the real visitor IP. Without it, all clicks will appear to come from the server\'s IP.',
        s, RULER_RED)
    story.append(PageBreak())

    # ── 3. ENVIRONMENT CONFIG ──────────────────────────────────────────────────
    story += section_tag('03 — Environment Configuration', s)
    story.append(Paragraph('The .env File', s['h1']))
    story.append(Paragraph(
        'Copy .env.example to .env and fill in the values below. Never commit .env to git. '
        'All Google Ads and Meta credentials are set per-client from the dashboard — '
        'the .env values are fallbacks for single-account setups.', s['body']))

    story += code_block([
        '# ── Server ────────────────────────────────────────',
        'PORT=3000',
        'DASHBOARD_PASSWORD=choose_a_strong_password_here',
        '',
        '# ── Fraud Thresholds (defaults, overridable per client) ──',
        'CLICK_THRESHOLD=3       # Clicks from same IP in 24h before flagging',
        'AUTO_BLOCK_SCORE=75     # Score at which IP is auto-blocked',
        'TARGET_COUNTRIES=GR     # Comma-separated ISO2 codes (blank = any country)',
        '',
        '# ── Google Ads (fallback / single-account) ────────',
        'GOOGLE_ADS_CLIENT_ID=',
        'GOOGLE_ADS_CLIENT_SECRET=',
        'GOOGLE_ADS_DEVELOPER_TOKEN=',
        'GOOGLE_ADS_REFRESH_TOKEN=',
        'GOOGLE_ADS_CUSTOMER_ID=  # digits only, e.g. 9487542725',
        '',
        '# ── Meta Ads (fallback / single-account) ──────────',
        'META_ACCESS_TOKEN=',
        'META_AD_ACCOUNT_ID=      # format: act_XXXXXXX',
    ], s, label='.env')
    story.append(PageBreak())

    # ── 4. GOOGLE ADS SETUP ───────────────────────────────────────────────────
    story += section_tag('04 — Google Ads API', s)
    story.append(Paragraph('Connecting Google Ads', s['h1']))
    story.append(Paragraph(
        'The integration uses the Google Ads REST API to create IP exclusion lists and '
        'attach them to all active campaigns. Each client can have their own credentials '
        'configured from the dashboard.', s['body']))

    story.append(Paragraph('Step 1 — Google Cloud Project', s['h2']))
    story += code_block([
        '1. Go to console.cloud.google.com',
        '2. Create a new project (e.g. "Ruler Ad Guard")',
        '3. Navigate to APIs & Services → Library',
        '4. Search "Google Ads API" and click Enable',
        '5. Go to APIs & Services → Credentials',
        '6. Click Create Credentials → OAuth 2.0 Client ID',
        '7. Application type: Desktop App',
        '8. Download the JSON — note client_id and client_secret',
    ], s, label='Google Cloud Console')

    story.append(Paragraph('Step 2 — Developer Token', s['h2']))
    story += code_block([
        '1. Log into Google Ads (ads.google.com)',
        '2. Tools & Settings (wrench icon) → Setup → API Center',
        '3. Apply for a Developer Token',
        '   - For production use, apply for "Basic Access"',
        '   - For testing only, "Test Account" level is sufficient',
        '4. Copy the developer token once approved',
    ], s, label='Google Ads Account')

    story.append(Paragraph('Step 3 — OAuth Refresh Token', s['h2']))
    story.append(Paragraph('Use the OAuth Playground to generate a refresh token:', s['body']))
    story += code_block([
        '1. Go to developers.google.com/oauthplayground',
        '2. Click gear icon (settings) → check "Use your own OAuth credentials"',
        '3. Enter your client_id and client_secret',
        '4. In Step 1, find "Google Ads API" → select all scopes',
        '   OR manually enter: https://www.googleapis.com/auth/adwords',
        '5. Click "Authorize APIs" and complete the Google login',
        '6. In Step 2, click "Exchange authorization code for tokens"',
        '7. Copy the refresh_token value',
    ], s, label='OAuth Playground')

    story += alert(
        '<b>Note:</b> The refresh token does not expire unless the user revokes access '
        'or the app is in "Testing" mode (then it expires after 7 days). '
        'For production, publish your OAuth app in Google Cloud Console.',
        s, AMBER)
    story.append(PageBreak())

    # ── 5. META ADS SETUP ────────────────────────────────────────────────────
    story += section_tag('05 — Meta Ads API', s)
    story.append(Paragraph('Connecting Meta Ads', s['h1']))
    story.append(Paragraph(
        'The Meta integration creates a custom suppression audience named "RulerAdGuard — Blocked IPs" '
        'and attaches it as an exclusion to all active ad sets. '
        'Because Meta does not support raw IP exclusions, the blocked IP is hashed with SHA-256 '
        'and added to a custom audience, which is then excluded from targeting.',
        s['body']))

    story.append(Paragraph('Step 1 — Create a Meta App', s['h2']))
    story += code_block([
        '1. Go to developers.facebook.com → My Apps → Create App',
        '2. Select "Other" as use case → "Business" type',
        '3. Add product: Marketing API',
        '4. Note the App ID and App Secret',
    ], s, label='Meta for Developers')

    story.append(Paragraph('Step 2 — Generate Access Token', s['h2']))
    story.append(Paragraph(
        'For production, create a System User token (longer-lived, not tied to a personal account):', s['body']))
    story += code_block([
        '# Option A: System User (recommended for production)',
        '1. Business Settings → Users → System Users',
        '2. Create a System User with "Admin" role',
        '3. Add Assets → Ad Accounts → assign the client\'s ad account',
        '4. Generate New Token → select: ads_management, ads_read',
        '5. Copy the token (it does not expire unless manually revoked)',
        '',
        '# Option B: User Token (simpler, expires in 60 days)',
        '1. Use the Graph API Explorer at developers.facebook.com/tools/explorer',
        '2. Select your app, click "Generate Access Token"',
        '3. Add permissions: ads_management, ads_read',
        '4. Extend the token: exchange it for a long-lived token via:',
        '   GET /oauth/access_token?grant_type=fb_exchange_token',
        '       &client_id={APP_ID}&client_secret={APP_SECRET}',
        '       &fb_exchange_token={SHORT_TOKEN}',
    ], s, label='Meta Business Manager')

    story.append(Paragraph('Step 3 — Find Ad Account ID', s['h2']))
    story += code_block([
        '# Call the Graph API to list ad accounts:',
        'curl "https://graph.facebook.com/v20.0/me/adaccounts',
        '      ?fields=id,name&access_token=YOUR_TOKEN"',
        '',
        '# Response will list IDs in format: act_XXXXXXXXX',
        '# Use this value as META_AD_ACCOUNT_ID',
    ], s, label='Find Ad Account ID')
    story.append(PageBreak())

    # ── 6. TRACKER SNIPPET ────────────────────────────────────────────────────
    story += section_tag('06 — Tracker Snippet', s)
    story.append(Paragraph('Installing the Tracking Script', s['h1']))
    story.append(Paragraph(
        'The tracker.js script must be installed on every landing page connected to '
        'a Google Ads or Meta Ads campaign. It fires on page load, captures click metadata '
        '(gclid, fbclid, user-agent, referrer), and sends it to the server for fraud scoring.',
        s['body']))

    story.append(Paragraph('Per-Client Setup', s['h2']))
    story.append(Paragraph(
        'Each client website gets a unique API key generated from the dashboard (Clients tab). '
        'Use that key in their snippet:', s['body']))
    story += code_block([
        '<!-- Ruler Ad Guard — [Client Name] -->',
        '<!-- Place in <head> on every landing page -->',
        '<script>',
        '  var FRAUD_TRACKER_SERVER = "https://guard.ruler.agency";',
        '  var FRAUD_TRACKER_KEY    = "rfs_abc123...";  /* client API key */',
        '</script>',
        '<script src="https://guard.ruler.agency/tracker.js"></script>',
    ], s, label='HTML — landing page <head>')

    story.append(Paragraph('Conversion Tracking', s['h2']))
    story.append(Paragraph(
        'Fire this on the thank-you / confirmation page so converted clicks '
        'are marked as legitimate and removed from fraud suspicion:', s['body']))
    story += code_block([
        '<script>',
        '  // After a successful form submission or purchase',
        '  fraudTrackerConversion(150);  // pass order value in EUR (optional)',
        '</script>',
    ], s, label='HTML — thank-you page')

    story.append(Paragraph('What the Tracker Captures', s['h2']))
    story += info_table([
        ('gclid / fbclid', 'Google / Meta click IDs from URL parameters'),
        ('utm_campaign',   'Campaign ID from UTM parameters'),
        ('User-Agent',     'Browser and OS fingerprint'),
        ('Referrer',       'Source page URL'),
        ('Landing URL',    'Full URL including all query params'),
        ('Time on page',   'Seconds from load to exit/hidden'),
        ('Scroll depth',   'Maximum scroll percentage (0–100%)'),
        ('Mouse movement', 'Boolean — any movement detected'),
    ], s)
    story.append(PageBreak())

    # ── 7. DASHBOARD ─────────────────────────────────────────────────────────
    story += section_tag('07 — Dashboard', s)
    story.append(Paragraph('Using the Dashboard', s['h1']))
    story.append(Paragraph(
        'Access the dashboard at your server URL with the dashboard password as a query parameter:', s['body']))
    story += code_block([
        'https://guard.ruler.agency?key=your_dashboard_password',
    ], s, label='Dashboard URL')

    story.append(Paragraph('Dashboard Features', s['h2']))
    feat_data = [
        ['Section', 'Description'],
        ['Overview', 'Summary stats, clicks-over-time chart, top offending IPs, fraud signal breakdown'],
        ['Click Log', 'Full paginated log with score, verdict, flags, session data per click. Filter by fraud/suspicious/clean'],
        ['Blocked IPs', 'All blocked IPs with push status (Google / Meta). Unblock individual IPs'],
        ['Clients', 'Add and manage client websites. View their API keys and connection status'],
        ['Setup', 'Per-client tracking snippet generator, manual IP block, MCP config'],
    ]
    feat_tbl = Table(feat_data, colWidths=[40*mm, W - 30*mm - 40*mm])
    feat_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), SURFACE),
        ('BACKGROUND', (0,1), (-1,-1), CARD),
        ('TEXTCOLOR',  (0,0), (-1,0), TEXT_3),
        ('FONTNAME',   (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE',   (0,0), (-1,-1), 8),
        ('GRID', (0,0), (-1,-1), 0.3, BORDER),
        ('TOPPADDING',   (0,0), (-1,-1), 7),
        ('BOTTOMPADDING',(0,0), (-1,-1), 7),
        ('LEFTPADDING',  (0,0), (-1,-1), 8),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [CARD, colors.HexColor('#131825')]),
    ]))
    story.append(feat_tbl)
    story.append(Spacer(1, 3*mm))

    story.append(Paragraph('Adding a Client', s['h2']))
    story += code_block([
        '1. Open the dashboard → Clients tab',
        '2. Click "+ Add Client"',
        '3. Enter the client name and domain',
        '4. Copy the generated API key (rfs_...)',
        '5. Go to Setup tab → select the client from the dropdown',
        '6. Copy the tracking snippet and send to the client\'s developer',
        '7. Configure Google Ads and Meta credentials via PUT /api/dashboard/clients/:id',
        '   (or add a credentials form to the dashboard if needed)',
    ], s, label='Workflow')
    story.append(PageBreak())

    # ── 8. API REFERENCE ─────────────────────────────────────────────────────
    story += section_tag('08 — API Reference', s)
    story.append(Paragraph('REST API Endpoints', s['h1']))

    story.append(Paragraph('Tracker Endpoints (public — require X-Api-Key header)', s['h2']))
    api_data = [
        ['Method', 'Path', 'Description'],
        ['POST', '/api/track/click',      'Record a click event. Body: { ua, referrer, landing_url, gclid, fbclid, session_id, campaign_id, ad_group_id }'],
        ['POST', '/api/track/session',    'Update session quality. Body: { click_id, session_id, time_on_page, scroll_depth, mouse_moved, clicks_count }'],
        ['POST', '/api/track/conversion', 'Mark click as converted. Body: { gclid?, fbclid?, value? }'],
    ]
    api_tbl = Table(api_data, colWidths=[14*mm, 44*mm, W - 30*mm - 14*mm - 44*mm])
    api_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), SURFACE),
        ('BACKGROUND', (0,1), (-1,-1), CARD),
        ('TEXTCOLOR',  (0,0), (-1,0), TEXT_3),
        ('TEXTCOLOR',  (0,1), (0,-1), RULER_RED),
        ('FONTNAME',   (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTNAME',   (0,1), (0,-1), 'Courier-Bold'),
        ('FONTSIZE',   (0,0), (-1,-1), 7.5),
        ('GRID', (0,0), (-1,-1), 0.3, BORDER),
        ('TOPPADDING',   (0,0), (-1,-1), 6),
        ('BOTTOMPADDING',(0,0), (-1,-1), 6),
        ('LEFTPADDING',  (0,0), (-1,-1), 7),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [CARD, colors.HexColor('#131825')]),
    ]))
    story.append(api_tbl)
    story.append(Spacer(1, 4*mm))

    story.append(Paragraph('Dashboard Endpoints (require X-Dashboard-Key header)', s['h2']))
    dash_data = [
        ['Method', 'Path', 'Description'],
        ['GET',    '/api/dashboard/clients',              'List all clients'],
        ['POST',   '/api/dashboard/clients',              'Create client. Body: { name, domain }'],
        ['PUT',    '/api/dashboard/clients/:id',          'Update client credentials'],
        ['DELETE', '/api/dashboard/clients/:id',          'Deactivate client'],
        ['GET',    '/api/dashboard/stats?days=&client_id=',    'Aggregate fraud stats'],
        ['GET',    '/api/dashboard/clicks?days=&filter=&client_id=', 'Paginated click log'],
        ['GET',    '/api/dashboard/chart?days=&client_id=',    'Time-series chart data'],
        ['GET',    '/api/dashboard/top-fraud-ips?client_id=',  'Top offending IPs'],
        ['GET',    '/api/dashboard/flag-breakdown?client_id=', 'Fraud signal counts'],
        ['GET',    '/api/dashboard/blocked-ips?client_id=',    'All blocked IPs'],
        ['POST',   '/api/dashboard/block',               'Block IP. Body: { ip, client_id, platforms[] }'],
        ['DELETE', '/api/dashboard/block/:client_id/:ip','Unblock IP'],
        ['POST',   '/api/dashboard/meta/attach-exclusion','Sync exclusion to all Meta ad sets'],
    ]
    dash_tbl = Table(dash_data, colWidths=[15*mm, 67*mm, W - 30*mm - 15*mm - 67*mm])
    dash_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), SURFACE),
        ('BACKGROUND', (0,1), (-1,-1), CARD),
        ('TEXTCOLOR',  (0,0), (-1,0), TEXT_3),
        ('TEXTCOLOR',  (0,1), (0,-1), RULER_RED),
        ('FONTNAME',   (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTNAME',   (0,1), (0,-1), 'Courier-Bold'),
        ('FONTSIZE',   (0,0), (-1,-1), 7),
        ('GRID', (0,0), (-1,-1), 0.3, BORDER),
        ('TOPPADDING',   (0,0), (-1,-1), 5),
        ('BOTTOMPADDING',(0,0), (-1,-1), 5),
        ('LEFTPADDING',  (0,0), (-1,-1), 7),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [CARD, colors.HexColor('#131825')]),
    ]))
    story.append(dash_tbl)
    story.append(PageBreak())

    # ── 9. MCP SERVER ────────────────────────────────────────────────────────
    story += section_tag('09 — MCP Server', s)
    story.append(Paragraph('Claude Code Integration', s['h1']))
    story.append(Paragraph(
        'The MCP server (mcp-server.js) exposes 13 tools to Claude Code via the '
        'Model Context Protocol over stdio. Once configured, any team member using '
        'Claude Code can query and manage fraud data through natural language.',
        s['body']))

    story.append(Paragraph('Configuration', s['h2']))
    story += code_block([
        '// Add to ~/.claude/settings.json (on each team member\'s machine)',
        '{',
        '  "mcpServers": {',
        '    "ruler-ad-guard": {',
        '      "command": "node",',
        '      "args": ["/var/www/ruler-ad-guard/mcp-server.js"]',
        '    }',
        '  }',
        '}',
    ], s, label='~/.claude/settings.json')

    story.append(Paragraph('Available MCP Tools', s['h2']))
    mcp_data = [
        ['Tool', 'Description'],
        ['list_clients',           'List all tracked client websites'],
        ['create_client',          'Register a new client (returns API key)'],
        ['get_fraud_stats',        'Summary stats for a client or all clients'],
        ['get_recent_fraud',       'Recent fraud/suspicious clicks with details'],
        ['get_top_fraud_ips',      'Top IPs generating fraud clicks'],
        ['get_blocked_ips',        'All currently blocked IPs'],
        ['block_ip',               'Block an IP and push to Google + Meta'],
        ['unblock_ip',             'Remove an IP from the block list'],
        ['get_flag_breakdown',     'Which fraud signals are triggering most'],
        ['sync_meta_exclusions',   'Attach suppression audience to all Meta ad sets'],
        ['get_google_campaign_stats', 'Pull campaign stats incl. invalid click rate'],
        ['get_meta_campaign_stats',   'Pull Meta campaign stats'],
        ['get_client_snippet',     'Generate the tracker snippet for a client'],
    ]
    mcp_tbl = Table(mcp_data, colWidths=[52*mm, W - 30*mm - 52*mm])
    mcp_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), SURFACE),
        ('BACKGROUND', (0,1), (-1,-1), CARD),
        ('TEXTCOLOR',  (0,0), (-1,0), TEXT_3),
        ('TEXTCOLOR',  (0,1), (0,-1), RULER_RED),
        ('FONTNAME',   (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTNAME',   (0,1), (0,-1), 'Courier'),
        ('FONTSIZE',   (0,0), (-1,-1), 8),
        ('GRID', (0,0), (-1,-1), 0.3, BORDER),
        ('TOPPADDING',   (0,0), (-1,-1), 6),
        ('BOTTOMPADDING',(0,0), (-1,-1), 6),
        ('LEFTPADDING',  (0,0), (-1,-1), 8),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [CARD, colors.HexColor('#131825')]),
    ]))
    story.append(mcp_tbl)
    story.append(Spacer(1, 3*mm))

    story.append(Paragraph('Example Claude Code Queries', s['h2']))
    story += code_block([
        '"Show me the fraud stats for the Ena client this month"',
        '"What are the top 10 offending IPs across all clients?"',
        '"Block IP 45.33.12.1 for client X and push to Google and Meta"',
        '"Create a new client called Demo Shop with domain demoshop.gr"',
        '"Get the tracking snippet for the Ena client"',
        '"Sync the Meta exclusions for all clients"',
    ], s, label='Example natural-language queries in Claude Code')
    story.append(PageBreak())

    # ── 10. SECURITY CHECKLIST ────────────────────────────────────────────────
    story += section_tag('10 — Security & Checklist', s)
    story.append(Paragraph('Go-Live Checklist', s['h1']))

    checklist = [
        ('Server', [
            'Node.js 18+ installed and running',
            'npm install --production completed successfully',
            '.env file created with all credentials',
            'PM2 configured and auto-start enabled',
            'Nginx configured as reverse proxy with SSL (HTTPS)',
            'X-Forwarded-For header passed through to Node',
            'Firewall: only port 80/443 exposed publicly (3000 blocked)',
        ]),
        ('Google Ads', [
            'Google Cloud project created with Ads API enabled',
            'OAuth 2.0 client credentials obtained',
            'Developer Token approved (Basic Access for production)',
            'Refresh token generated via OAuth Playground',
            'Credentials added to .env or client settings',
            'Test: verify /api/dashboard/google-stats returns data',
        ]),
        ('Meta Ads', [
            'Meta App created with Marketing API product',
            'System User created in Business Manager',
            'Access token generated with ads_management permission',
            'Ad Account ID confirmed (act_XXXXXXXXX format)',
            'Credentials added to .env or client settings',
            'Test: verify "RulerAdGuard — Blocked IPs" audience created in Meta',
            'Run "Sync Meta Ad Sets" to attach exclusion to active ad sets',
        ]),
        ('Per-Client', [
            'Client created in dashboard (Clients tab)',
            'API key noted and securely stored',
            'Tracker snippet installed on all landing pages (inside <head>)',
            'Conversion tracking added to thank-you page',
            'Test click: visit a landing page with ?gclid=test123 in the URL',
            'Verify test click appears in Click Log',
            'Set TARGET_COUNTRIES per client if geographic targeting needed',
        ]),
    ]

    for section_name, items in checklist:
        story.append(Paragraph(section_name, s['h2']))
        check_rows = [[
            Paragraph('☐', ParagraphStyle('cb', fontName='Helvetica', fontSize=10, textColor=RULER_RED)),
            Paragraph(item, s['body'])
        ] for item in items]
        check_tbl = Table(check_rows, colWidths=[8*mm, W - 30*mm - 8*mm])
        check_tbl.setStyle(TableStyle([
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('TOPPADDING',   (0,0), (-1,-1), 3),
            ('BOTTOMPADDING',(0,0), (-1,-1), 3),
            ('LEFTPADDING',  (0,0), (-1,-1), 2),
        ]))
        story.append(check_tbl)
        story.append(Spacer(1, 2*mm))

    story.append(Spacer(1, 4*mm))
    story += alert(
        '<b>Security reminder:</b> The .env file contains API credentials with billing access. '
        'Never commit it to git, never share it over unencrypted channels, and rotate tokens '
        'immediately if they are ever exposed. Use a secrets manager (AWS Secrets Manager, '
        'HashiCorp Vault) for production deployments.',
        s, RULER_RED)

    # ── BACK COVER ─────────────────────────────────────────────────────────────
    story.append(PageBreak())
    back = [
        Spacer(1, 30*mm),
        Paragraph('R', ParagraphStyle('bigr', fontName='Helvetica-Bold', fontSize=80,
            textColor=RULER_RED, alignment=TA_CENTER, leading=80)),
        Spacer(1, 4*mm),
        Paragraph('RULER AGENCY', ParagraphStyle('ra', fontName='Helvetica-Bold', fontSize=12,
            textColor=WHITE, alignment=TA_CENTER, letterSpacing=4)),
        Spacer(1, 2*mm),
        Paragraph('ruler.agency', ParagraphStyle('url', fontName='Helvetica', fontSize=10,
            textColor=TEXT_3, alignment=TA_CENTER)),
        Spacer(1, 12*mm),
        HRFlowable(width='40%', thickness=0.5, color=BORDER),
        Spacer(1, 8*mm),
        Paragraph(
            'Questions about this brief?<br/>Contact the Ruler Agency team before starting implementation.',
            ParagraphStyle('qs', fontName='Helvetica', fontSize=9, textColor=TEXT_3,
            alignment=TA_CENTER, leading=16)),
    ]

    back_tbl = Table([back], colWidths=[W - 30*mm])
    back_tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), DARK_BG),
        ('LEFTPADDING',  (0,0), (-1,-1), 14),
        ('RIGHTPADDING', (0,0), (-1,-1), 14),
        ('TOPPADDING',   (0,0), (-1,-1), 0),
        ('BOTTOMPADDING',(0,0), (-1,-1), 0),
    ]))
    story.append(back_tbl)

    # ── Build ─────────────────────────────────────────────────────────────────
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
    print(f'PDF saved: {out_path}')
    return out_path


if __name__ == '__main__':
    build()
