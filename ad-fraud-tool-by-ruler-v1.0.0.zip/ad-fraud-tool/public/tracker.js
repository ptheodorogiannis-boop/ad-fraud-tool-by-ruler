/**
 * Ruler Ad Guard — Tracking Snippet
 *
 * Usage (add to every landing page <head>):
 *   <script>
 *     var FRAUD_TRACKER_SERVER = "https://guard.ruler.agency";
 *     var FRAUD_TRACKER_KEY    = "rfs_your_client_api_key";
 *   </script>
 *   <script src="https://guard.ruler.agency/tracker.js"></script>
 *
 * On thank-you page, call: fraudTrackerConversion(value)
 */
(function () {
  var SERVER = (typeof FRAUD_TRACKER_SERVER !== 'undefined') ? FRAUD_TRACKER_SERVER : 'http://localhost:3000';
  var API_KEY = (typeof FRAUD_TRACKER_KEY !== 'undefined') ? FRAUD_TRACKER_KEY : '';

  var sessionId   = Math.random().toString(36).slice(2) + Date.now().toString(36);
  var clickId     = null;
  var startTime   = Date.now();
  var scrollDepth = 0;
  var mouseMoved  = false;
  var pageClicks  = 0;
  var sessionSent = false;

  function getParam(name) {
    return new URL(window.location.href).searchParams.get(name) || null;
  }

  function trackClick() {
    fetch(SERVER + '/api/track/click', {
      method:    'POST',
      headers:   { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
      keepalive: true,
      body: JSON.stringify({
        ua:          navigator.userAgent,
        referrer:    document.referrer,
        landing_url: window.location.href,
        gclid:       getParam('gclid'),
        fbclid:      getParam('fbclid'),
        session_id:  sessionId,
        campaign_id: getParam('utm_campaign') || getParam('campaignid'),
        ad_group_id: getParam('adgroupid')    || getParam('utm_content'),
        api_key:     API_KEY,
      }),
    })
    .then(function (r) { return r.json(); })
    .then(function (d) { if (d && d.click_id) clickId = d.click_id; })
    .catch(function () {});
  }

  document.addEventListener('mousemove', function () { mouseMoved = true; }, { once: true });
  document.addEventListener('click',     function () { pageClicks++; });
  window.addEventListener('scroll', function () {
    var d = Math.round((window.scrollY + window.innerHeight) / document.body.scrollHeight * 100);
    if (d > scrollDepth) scrollDepth = d;
  }, { passive: true });

  function sendSession() {
    if (sessionSent) return;
    sessionSent = true;
    var payload = JSON.stringify({
      api_key:     API_KEY,
      click_id:    clickId,
      session_id:  sessionId,
      time_on_page: Math.round((Date.now() - startTime) / 1000),
      scroll_depth: scrollDepth,
      mouse_moved:  mouseMoved,
      clicks_count: pageClicks,
    });
    navigator.sendBeacon
      ? navigator.sendBeacon(SERVER + '/api/track/session', payload)
      : fetch(SERVER + '/api/track/session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
          body: payload, keepalive: true,
        }).catch(function () {});
  }

  // Heartbeat — reset flag so each heartbeat fires
  setInterval(function () { sessionSent = false; sendSession(); }, 30000);

  window.addEventListener('beforeunload', sendSession);
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') sendSession();
  });

  window.fraudTrackerConversion = function (value) {
    fetch(SERVER + '/api/track/conversion', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
      body:    JSON.stringify({ gclid: getParam('gclid'), fbclid: getParam('fbclid'), value: value||0, api_key: API_KEY }),
      keepalive: true,
    }).catch(function () {});
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', trackClick);
  } else {
    trackClick();
  }
})();
