# FraudShield — Self-Hosted Ad Fraud Tool

Detects and blocks invalid/fraudulent clicks from Google Ads and Meta Ads campaigns. Auto-pushes blocked IPs to Google Ads IP exclusion lists and Meta Ads custom audience exclusions.

---

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env with your credentials
```

### 3. Run
```bash
npm start
# Dashboard → http://localhost:3000?key=your-password
```

---

## Credential Setup

### Google Ads
1. Go to [Google Cloud Console](https://console.cloud.google.com) → Create a project
2. Enable **Google Ads API**
3. Create OAuth 2.0 credentials (Desktop app)
4. Get a refresh token via OAuth playground or `google-auth-library`
5. Apply for a **Developer Token** in your Google Ads account under Tools → API Center
6. Fill in `.env`:
   ```
   GOOGLE_ADS_CLIENT_ID=...
   GOOGLE_ADS_CLIENT_SECRET=...
   GOOGLE_ADS_DEVELOPER_TOKEN=...
   GOOGLE_ADS_REFRESH_TOKEN=...
   GOOGLE_ADS_CUSTOMER_ID=9487542725
   ```

### Meta Ads
1. Go to [Meta for Developers](https://developers.facebook.com) → Create an App
2. Add **Marketing API** product
3. Generate a User or System User access token with `ads_management` permission
4. Fill in `.env`:
   ```
   META_ACCESS_TOKEN=...
   META_AD_ACCOUNT_ID=act_XXXXXXX
   ```

---

## Tracking Snippet

Add to every landing page `<head>`:

```html
<script>
  var FRAUD_TRACKER_SERVER = "https://your-server.com";
</script>
<script src="https://your-server.com/tracker.js"></script>
```

The snippet auto-captures `gclid` (Google) and `fbclid` (Meta) from the URL.

### Conversion tracking (thank-you page)
```html
<script>
  fraudTrackerConversion(150); // optional: order value in EUR
</script>
```

---

## Fraud Scoring

Each click is scored 0–100:

| Signal | Points |
|--------|--------|
| Repeat IP (>3 clicks/24h) | 30–45 |
| Datacenter/VPN/Tor IP | 35 |
| Bot user-agent | 40 |
| Suspicious UA (spoofed/ancient) | 15 |
| Missing user-agent | 20 |
| Session < 3 seconds | 20 |
| No mouse movement | 10 |
| No scroll | 8 |
| Geo mismatch (outside target countries) | 20 |
| Missing gclid/fbclid | 5 |

**Score ≥ 75** → Auto-blocked and pushed to Google + Meta  
**Score 40–74** → Suspicious, flagged for review  
**Score < 40** → Clean

---

## Architecture

```
ad-fraud-tool/
├── server.js              # Express API + auto-block logic
├── fraud-engine.js        # Scoring algorithm
├── db.js                  # SQLite schema + connection
├── integrations/
│   ├── google-ads.js      # IP exclusion list management
│   └── meta-ads.js        # Custom audience exclusion
└── public/
    ├── tracker.js         # Client-side snippet (drop on landing pages)
    └── index.html         # Dashboard
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/track/click` | Record a click (called by tracker.js) |
| POST | `/api/track/session` | Update session quality data |
| POST | `/api/track/conversion` | Mark a click as converted |
| GET | `/api/dashboard/stats` | Summary stats |
| GET | `/api/dashboard/clicks` | Paginated click log |
| GET | `/api/dashboard/blocked-ips` | All blocked IPs |
| POST | `/api/dashboard/block` | Manually block an IP |
| DELETE | `/api/dashboard/block/:ip` | Unblock an IP |
| POST | `/api/dashboard/meta/attach-exclusion` | Sync exclusion to all Meta ad sets |
