const fetch = require('node-fetch');
const { db } = require('../db');

const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const ADS_BASE  = 'https://googleads.googleapis.com/v17';

// Per-client token cache
const tokenCache = {};

async function getAccessToken(client) {
  const cid = client.id;
  const cached = tokenCache[cid];
  if (cached && Date.now() < cached.expiry) return cached.token;

  const resp = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id:     client.google_client_id     || process.env.GOOGLE_ADS_CLIENT_ID,
      client_secret: client.google_client_secret || process.env.GOOGLE_ADS_CLIENT_SECRET,
      refresh_token: client.google_refresh_token || process.env.GOOGLE_ADS_REFRESH_TOKEN,
      grant_type:    'refresh_token',
    }),
  });
  if (!resp.ok) throw new Error(`Google token refresh: ${await resp.text()}`);
  const data = await resp.json();
  tokenCache[cid] = { token: data.access_token, expiry: Date.now() + (data.expires_in - 60) * 1000 };
  return data.access_token;
}

function headers(token, client) {
  return {
    Authorization:    `Bearer ${token}`,
    'developer-token': client.google_dev_token || process.env.GOOGLE_ADS_DEVELOPER_TOKEN,
    'Content-Type':   'application/json',
  };
}

function customerId(client) {
  return (client.google_customer_id || process.env.GOOGLE_ADS_CUSTOMER_ID || '').replace(/-/g, '');
}

async function listExclusionLists(client) {
  const token = await getAccessToken(client);
  const cid   = customerId(client);
  const resp  = await fetch(`${ADS_BASE}/customers/${cid}/googleAds:search`, {
    method: 'POST',
    headers: headers(token, client),
    body: JSON.stringify({ query: `SELECT ip_block.id, ip_block.name FROM ip_block ORDER BY ip_block.name` }),
  });
  if (!resp.ok) throw new Error(`listExclusionLists: ${await resp.text()}`);
  return resp.json();
}

async function createExclusionList(client, name = 'RulerAdGuard — Blocked IPs') {
  const token = await getAccessToken(client);
  const cid   = customerId(client);
  const resp  = await fetch(`${ADS_BASE}/customers/${cid}/ipBlocks:mutate`, {
    method: 'POST',
    headers: headers(token, client),
    body: JSON.stringify({ operations: [{ create: { name } }] }),
  });
  if (!resp.ok) throw new Error(`createExclusionList: ${await resp.text()}`);
  const data = await resp.json();
  return data.results[0].resourceName;
}

const listResourceCache = {};
async function blockIpInGoogle(client, ip, listResourceName) {
  const token = await getAccessToken(client);
  const cid   = customerId(client);

  // Get or create the list
  if (!listResourceName) {
    if (!listResourceCache[client.id]) {
      const lists = await listExclusionLists(client);
      const existing = (lists.results || []).find(r => r.ipBlock?.name === 'RulerAdGuard — Blocked IPs');
      listResourceCache[client.id] = existing
        ? existing.ipBlock.resourceName
        : await createExclusionList(client);
    }
    listResourceName = listResourceCache[client.id];
  }

  const resp = await fetch(`${ADS_BASE}/customers/${cid}/ipBlocks:mutate`, {
    method: 'POST',
    headers: headers(token, client),
    body: JSON.stringify({
      operations: [{ create: { ipBlock: listResourceName, ipAddress: ip } }],
    }),
  });

  const ok = resp.ok;
  const txt = await resp.text();
  logPush(client.id, ip, 'google', ok ? 'success' : 'error', txt);
  if (!ok) throw new Error(`blockIpInGoogle: ${txt}`);
  return listResourceName;
}

async function getCampaignStats(client, days = 30) {
  const token = await getAccessToken(client);
  const cid   = customerId(client);
  const resp  = await fetch(`${ADS_BASE}/customers/${cid}/googleAds:search`, {
    method: 'POST',
    headers: headers(token, client),
    body: JSON.stringify({
      query: `
        SELECT campaign.id, campaign.name, campaign.status,
          metrics.clicks, metrics.impressions, metrics.cost_micros,
          metrics.conversions, metrics.invalid_clicks, metrics.invalid_click_rate
        FROM campaign
        WHERE segments.date DURING LAST_${days}_DAYS
          AND campaign.status != 'REMOVED'
        ORDER BY metrics.cost_micros DESC LIMIT 50
      `,
    }),
  });
  if (!resp.ok) throw new Error(`getCampaignStats: ${await resp.text()}`);
  return resp.json();
}

function logPush(clientId, ip, platform, status, response) {
  try {
    db.prepare(`INSERT INTO exclusion_push_log (client_id,ip,platform,status,response) VALUES (?,?,?,?,?)`)
      .run(clientId, ip, platform, status, response);
  } catch {}
}

module.exports = { blockIpInGoogle, getCampaignStats };
