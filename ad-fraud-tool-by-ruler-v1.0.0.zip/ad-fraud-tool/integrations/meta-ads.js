const fetch  = require('node-fetch');
const crypto = require('crypto');
const { db } = require('../db');

const GRAPH = 'https://graph.facebook.com/v20.0';

const audienceCache = {};

function token(client)   { return client.meta_access_token || process.env.META_ACCESS_TOKEN; }
function account(client) { return client.meta_ad_account_id || process.env.META_AD_ACCOUNT_ID; }

async function getOrCreateFraudAudience(client) {
  const cid = client.id;
  if (audienceCache[cid]) return audienceCache[cid];

  const listResp = await fetch(
    `${GRAPH}/${account(client)}/customaudiences?fields=id,name&access_token=${token(client)}`
  );
  const list = await listResp.json();
  const existing = (list.data || []).find(a => a.name === 'RulerAdGuard — Blocked IPs');
  if (existing) { audienceCache[cid] = existing.id; return existing.id; }

  const createResp = await fetch(`${GRAPH}/${account(client)}/customaudiences`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name:        'RulerAdGuard — Blocked IPs',
      subtype:     'CUSTOM',
      description: 'Auto-blocked by Ruler Ad Guard',
      customer_file_source: 'USER_PROVIDED_ONLY',
      access_token: token(client),
    }),
  });
  if (!createResp.ok) throw new Error(`createAudience: ${await createResp.text()}`);
  const created = await createResp.json();
  audienceCache[cid] = created.id;
  return created.id;
}

async function blockIpInMeta(client, ip) {
  const audienceId = await getOrCreateFraudAudience(client);
  const hashedIp   = crypto.createHash('sha256').update(ip.trim().toLowerCase()).digest('hex');

  const resp = await fetch(`${GRAPH}/${audienceId}/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      payload: { schema: ['EMAIL'], data: [[hashedIp]] },
      access_token: token(client),
    }),
  });
  const result = await resp.json();
  logPush(client.id, ip, 'meta', resp.ok ? 'success' : 'error', JSON.stringify(result));
  if (!resp.ok) throw new Error(`blockIpInMeta: ${JSON.stringify(result)}`);
  return true;
}

async function attachExclusionToAdSets(client) {
  const audienceId = await getOrCreateFraudAudience(client);
  const resp = await fetch(
    `${GRAPH}/${account(client)}/adsets?fields=id,name,targeting&filtering=[{"field":"effective_status","operator":"IN","value":["ACTIVE"]}]&access_token=${token(client)}`
  );
  if (!resp.ok) throw new Error(`fetchAdSets: ${await resp.text()}`);
  const { data: adsets = [] } = await resp.json();

  const results = [];
  for (const adset of adsets) {
    const targeting  = adset.targeting || {};
    const exclusions = targeting.excluded_custom_audiences || [];
    if (exclusions.some(e => e.id === audienceId)) continue;
    exclusions.push({ id: audienceId });
    targeting.excluded_custom_audiences = exclusions;

    const up = await fetch(`${GRAPH}/${adset.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targeting, access_token: token(client) }),
    });
    results.push({ adset: adset.name, ok: up.ok });
  }
  return results;
}

async function getCampaignStats(client, days = 30) {
  const since = new Date(Date.now() - days*86400000).toISOString().slice(0,10);
  const until = new Date().toISOString().slice(0,10);
  const resp  = await fetch(
    `${GRAPH}/${account(client)}/campaigns?fields=id,name,status,insights{clicks,impressions,spend,cpc}&time_range={"since":"${since}","until":"${until}"}&access_token=${token(client)}`
  );
  if (!resp.ok) throw new Error(`getCampaignStats: ${await resp.text()}`);
  return resp.json();
}

function logPush(clientId, ip, platform, status, response) {
  try {
    db.prepare(`INSERT INTO exclusion_push_log (client_id,ip,platform,status,response) VALUES (?,?,?,?,?)`)
      .run(clientId, ip, platform, status, response);
  } catch {}
}

module.exports = { blockIpInMeta, attachExclusionToAdSets, getCampaignStats, getOrCreateFraudAudience };
