const Database = require('better-sqlite3');
const path = require('path');
const crypto = require('crypto');

const db = new Database(path.join(__dirname, 'data', 'fraud.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  -- ── Clients (multi-tenant) ────────────────────────────────────────────────
  CREATE TABLE IF NOT EXISTS clients (
    id                    TEXT PRIMARY KEY,
    name                  TEXT NOT NULL,
    domain                TEXT,
    api_key               TEXT UNIQUE NOT NULL,
    google_customer_id    TEXT,
    google_client_id      TEXT,
    google_client_secret  TEXT,
    google_dev_token      TEXT,
    google_refresh_token  TEXT,
    meta_access_token     TEXT,
    meta_ad_account_id    TEXT,
    click_threshold       INTEGER DEFAULT 3,
    auto_block_score      INTEGER DEFAULT 75,
    target_countries      TEXT DEFAULT '',
    created_at            INTEGER DEFAULT (unixepoch()),
    active                INTEGER DEFAULT 1
  );

  -- ── Clicks ────────────────────────────────────────────────────────────────
  CREATE TABLE IF NOT EXISTS clicks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   TEXT NOT NULL REFERENCES clients(id),
    ts          INTEGER NOT NULL DEFAULT (unixepoch()),
    ip          TEXT NOT NULL,
    country     TEXT,
    city        TEXT,
    ua          TEXT,
    device_type TEXT,
    browser     TEXT,
    os          TEXT,
    referrer    TEXT,
    landing_url TEXT,
    campaign_id TEXT,
    ad_group_id TEXT,
    gclid       TEXT,
    fbclid      TEXT,
    platform    TEXT,
    score       INTEGER DEFAULT 0,
    flags       TEXT DEFAULT '[]',
    blocked     INTEGER DEFAULT 0,
    converted   INTEGER DEFAULT 0
  );

  -- ── Sessions ──────────────────────────────────────────────────────────────
  CREATE TABLE IF NOT EXISTS sessions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    click_id      INTEGER REFERENCES clicks(id),
    session_id    TEXT UNIQUE,
    time_on_page  INTEGER,
    scroll_depth  INTEGER,
    mouse_moved   INTEGER DEFAULT 0,
    clicks_count  INTEGER DEFAULT 0,
    ts_start      INTEGER DEFAULT (unixepoch()),
    ts_end        INTEGER
  );

  -- ── Blocked IPs (per client) ──────────────────────────────────────────────
  CREATE TABLE IF NOT EXISTS blocked_ips (
    client_id   TEXT NOT NULL REFERENCES clients(id),
    ip          TEXT NOT NULL,
    reason      TEXT,
    score       INTEGER,
    blocked_at  INTEGER DEFAULT (unixepoch()),
    auto_pushed INTEGER DEFAULT 0,
    pushed_to   TEXT DEFAULT '[]',
    PRIMARY KEY (client_id, ip)
  );

  -- ── Conversions ───────────────────────────────────────────────────────────
  CREATE TABLE IF NOT EXISTS conversions (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    click_id  INTEGER REFERENCES clicks(id),
    gclid     TEXT,
    fbclid    TEXT,
    value     REAL,
    ts        INTEGER DEFAULT (unixepoch())
  );

  -- ── Exclusion push log ────────────────────────────────────────────────────
  CREATE TABLE IF NOT EXISTS exclusion_push_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id  TEXT,
    ip         TEXT,
    platform   TEXT,
    status     TEXT,
    response   TEXT,
    ts         INTEGER DEFAULT (unixepoch())
  );

  CREATE INDEX IF NOT EXISTS idx_clicks_client ON clicks(client_id);
  CREATE INDEX IF NOT EXISTS idx_clicks_ip     ON clicks(ip);
  CREATE INDEX IF NOT EXISTS idx_clicks_ts     ON clicks(ts);
  CREATE INDEX IF NOT EXISTS idx_clicks_gclid  ON clicks(gclid);
  CREATE INDEX IF NOT EXISTS idx_clicks_fbclid ON clicks(fbclid);
`);

// Helper: get client by API key
function getClientByKey(apiKey) {
  return db.prepare('SELECT * FROM clients WHERE api_key = ? AND active = 1').get(apiKey);
}

// Helper: get client by ID
function getClientById(id) {
  return db.prepare('SELECT * FROM clients WHERE id = ? AND active = 1').get(id);
}

// Helper: create client
function createClient({ name, domain, googleCustomerId, metaAdAccountId } = {}) {
  const id      = crypto.randomUUID();
  const api_key = 'rfs_' + crypto.randomBytes(20).toString('hex');
  db.prepare(`
    INSERT INTO clients (id, name, domain, api_key, google_customer_id, meta_ad_account_id)
    VALUES (?,?,?,?,?,?)
  `).run(id, name, domain || null, api_key, googleCustomerId || null, metaAdAccountId || null);
  return db.prepare('SELECT * FROM clients WHERE id = ?').get(id);
}

module.exports = { db, getClientByKey, getClientById, createClient };
